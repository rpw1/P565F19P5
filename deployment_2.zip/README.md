# P565F19P5
Installing project dependencies:
```
$ pip install -r requirements.txt
```

